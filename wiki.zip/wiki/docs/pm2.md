# 使用PM2管理应用

![logo](/images/pm2/pm2-v4.png)

**PM2是一个基于Nodejs的带有负载均衡功能的应用进程管理器。虽然是为node应用程序而生，但我们也可以用来管理Java或其他进程**

## 特性

- 内建负载均衡（使用 Node cluster 集群模块）
- 后台运行
- 0 秒停机重载
- 具有 Ubuntu 和 CentOS 的启动脚本
- 停止不稳定的进程（避免无限循环）
- 控制台检测
- 提供 HTTP API
- 远程控制和实时的接口 API ( Nodejs 模块,允许和 PM2 进程管理器交互 )
- GNU-AGPL-3.0

## 安装

```shell
$ npm set config registry http://   # 设置私服
$ npm i -g pm2  #全局安装
```

## 简单使用

1. 在应用程序目录创建启动配置文件`app.json`（文件名随意）

   ```json
   {
       "name": "demo",
       "script": "/usr/bin/java",
       "args": [
           "-jar",
           "demo.jar"
       ],
       "exec_interpreter": "",
       "exec_mode": "fork",
       "out_file" : "./logs/demo_out.log",
       "error_file" : "./logs/demo_error.log"
   }
   
   ```

   - `name`: 应用进程名，后面可以使用该字段进行启停管理；

   - `script`: 启动脚本路径；

   - `args`: 启动参数，与`scrpit`参数连起来后形成类似`/usr/bin/java -jar demo.jar`的一条完整命令；

   - `exec_interpreter`： 指定的node解释器，如果运行除node之外的程序，该项不适用；

   - `exec_mode`: 分为fork和cluster两种：

     - `fork`: 不可以启动多个实例进程(一般用于开发环境或基本运行环境)；
     - `cluster`: 可以启动多个实例，一般用于部署需要地址端口复用的情况；

   - `out_file`: 记录标准输出流位置（日志）

   - `error_file`: 记录标准错误流位置（日志）


2. 使用PM2调用该配置文件启动应用

   ```shell
   $ pm2 start app.json
   ```

   ![start](/images/pm2/start.png)

   应用启动后，pm2中就已经纳管了名为`demo`的任务，下次管理时就可以这样操作：

   ```shell
   $ pm2 restart demo    # 重启demo
   $ pm2 stop demo       # 停止demo
   ```

   
##  任务监控

   PM2对任务的监控有两种方式

- `pm2 list`:  使用该方式可以比较精简的看到所有任务的运行状态、资源使用情况

- `pm2 monit`: 可以看到较为详细的进程运行情况，包括实时刷新的日志

  ![monit](/images/pm2/monit.PNG")

  

##  自动重启

1. 达到指定的内存上限后重启，一般是防止进程出现内存泄漏时影响其他进程的正常运行。

    ```bash
    $ pm2 start demo --max-memory-restart 1024M
    ```

2. 进程意外终止时重启

    使用pm2运行demo后，使用kill直接杀死进程，可以看到，该应用立即重新启动。

    ![kill](/images/pm2/kill.PNG)

    3. 开机自启

       我们通常希望服务器在重启后自动启动我们的服务，使用PM2时，我们只用保证PM2注册到系统服务管理工具中即可。

       ```bash
       $ pm2 set pm2:autodump true
       ```

    

## 日志切割

之前使用nohup运行jar时，总是将标准输出流重定向到某文件，作为除应用中日志逻辑外的补充日志。这样做的话这个日志文件会越来越大，无论是对排查还是规范性上来说都不太好。pm2中的`pm2-logrotate`模块可以实现多种逻辑的日志切分功能。

```shell
$ pm2 install pm2-logrotate  
```

- `max_size`（默认为`10M`）：当文件大小大于此值时，切割日志。您可以在随后结束指定单位：`10G`，`10M`，`10K`；
- `retain`（默认为`30`文件日志）：此数字是一次保留的循环日志的数量，这意味着如果保留= 7，则最多将有7个循环日志和当前的日志；
- `compress`（默认为`false`）：通过gzip对所有切割的日志启用压缩；
- `dateFormat`（默认为`YYYY-MM-DD_HH-mm-ss`）：使用的数据格式名称为日志文件；
- `rotateModule`（默认为`true`）：像其他应用一样切割pm2模块的日志；
- `workerInterval`（默认为`30`秒）：您可以控制插件检查日志大小的时间间隔（最小为`1`）；
- `rotateInterval`（默认为`0 0 * * *`）：corn风格定时切割日志。

> corn 风格表达式：
>
> ```
> *    *    *    *    *    *
> ┬    ┬    ┬    ┬    ┬    ┬
> │    │    │    │    │    |
> │    │    │    │    │    └ day of week (0 - 7) (0 or 7 is Sun)
> │    │    │    │    └───── month (1 - 12)
> │    │    │    └────────── day of month (1 - 31)
> │    │    └─────────────── hour (0 - 23)
> │    └──────────────────── minute (0 - 59)
> └───────────────────────── second (0 - 59, OPTIONAL)
> ```

**当pm2-logrotate被install的时候，它就已经默认启动了一些切割规则，可以在`~/.pm2/module_conf.json`中查看**







