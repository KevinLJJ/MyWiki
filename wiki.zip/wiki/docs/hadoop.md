## YARN

1. 通过长期运行的守护进程提供自己的核心服务
    - 管理集群上资源使用的资源管理器(Resource Manager);
    - 运行 再集群中所有节点上且能够启动和监控容器的节点管理器(Node Manager).

# HDFS
## Introduction
　　Hadoop分布式文件系统（HDFS）是一种旨在在商品硬件上运行的分布式文件系统。它与现有的分布式文件系统有许多相似之处。但是，与其他分布式文件系统的区别很明显。HDFS具有高度的容错能力，旨在部署在低成本硬件上。HDFS提供对应用程序数据的高吞吐量访问，并且适用于具有大数据集的应用程序。
## HDFS Architecture

![HDFS架构](images/hdfs/hdfsarchitecture.png) 
HDFS具有主从体系结构，HDFS集群由单个管理文件命名空间的NameNode和多个数据节点DataNode组成。在集群内部，一个完整的文件被分为很多个块来存储，这些分块存储在一组DataNode中，NameNode保存了文件块到实际存储节点的映射（元数据），通过这个映射我们可以读取文件。

1. NameNode

    `hadoop/hdfs/name`:

    ```
    .
    ├── current
    │   ├── edits_0000000000000000001-0000000000000000001
    │   ├── edits_0000000000000000002-0000000000000000011
    │   ├── edits_inprogress_0000000000000000074
    │   ├── fsimage_0000000000000000073
    │   ├── fsimage_0000000000000000073.md5
    │   ├── seen_txid
    │   └── VERSION
    └── in_use.lock # 锁文件
    
    ```

    `hadoop/hdfs/name/current/VERSION`:

    ```
    #Sun Nov 24 21:17:07 EST 2019
    namespaceID=364314784  # 首次执行格式化时产生的命名空间ID
    clusterID=CID-f25514a0-1955-4058-a231-66a08b865ab9
    cTime=1574351591335 # NameNode创建的时间
    storageType=NAME_NODE # 当前目录
    blockpoolID=BP-2106182529-192.168.17.130-1574351591335
    layoutVersion=-63  # HDFS布局版本
    ```

2. DataNode:

    `hadoop/hdfs/data`:

    ```
    .
    ├── current
    │   ├── BP-2106182529-192.168.17.130-1574351591335 # 块池
    │   │   ├── current
    │   │   │   ├── dfsUsed
    │   │   │   ├── finalized
    │   │   │   │   └── subdir0
    │   │   │   │       └── subdir0
    │   │   │   │           ├── blk_1073741825 # 原始数据块
    │   │   │   │           ├── blk_1073741825_1001.meta # 对应的元数据文件
    │   │   │   │           ├── blk_1073741832
    │   │   │   │           ├── blk_1073741832_1008.meta
    │   │   │   │           ├── blk_1073741833
    │   │   │   │           └── blk_1073741833_1009.meta
    │   │   │   ├── rbw
    │   │   │   └── VERSION
    │   │   ├── scanner.cursor
    │   │   └── tmp
    │   └── VERSION
    └── in_use.lock # 锁文件
    
    ```

3. 文件冗余
	![块冗余](images/hdfs/hdfsdatanodes.png)
	
	- HDFS将每个文件存储为一系列的块，并且将这些块冗余到不同的DataNode节点上。其中块的大小和冗余份数（复制因子）是可以配置的，文件中除最后一个块外所有的块都有相同的大小（默认128MB）。
	
	- **冗余策略：**在常见情况下，当复制因子为3时，HDFS的放置策略是：如果写入器在数据节点上，则将一个副本放置在本地计算机上；否则，在随机数据节点上，将HDFS放置在不同（远程）机架中的节点上的另一个副本。 最后一个位于同一远程机架中的其他节点上。该策略减少了机架间的写流量，通常可以提高写性能。三分之一的副本位于一个节点上，三分之二的副本位于一个机架上，其余三分之一则平均分布在其余机架上。此策略可提高写入性能，而不会影响数据可靠性或读取性能。
	
如果复制因子大于3，则在确定每个机架的副本数量低于上限（基本上是`（副本-1）/机架+ 2`）以下的同时，随机确定第4个及以下副本的位置。
	
	    由于NameNode不允许DataNode具有同一块的多个副本，因此创建的副本的最大数量是当时DataNode的总数。
	    

## HDFS基本命令

### dfsadmin
   
| 命令选项                                    | 描述                                                         |
| --- | -------------- |
| `-report`                                     | 报告文件系统的基本信息和统计信息。                           |
| `-safemode enter \| leave \| get \| wait`    | 安全模式维护命令。安全模式是Namenode的一个状态，这种状态下，Namenode 1. 不接受对名字空间的更改(只读) 2. 不复制或删除块 Namenode会在启动时自动进入安全模式，当配置的块最小百分比数满足最小的副本数条件时，会自动离开安全模式。安全模式可以手动进入，但是这样的话也必须手动关闭安全模式。 |
| `-refreshNodes`                               | 重新读取hosts和exclude文件，更新允许连到Namenode的或那些需要退出或入编的Datanode的集合。 |
| `-finalizeUpgrade`                            | 终结HDFS的升级操作。Datanode删除前一个版本的工作目录，之后Namenode也这样做。这个操作完结整个升级过程。 |
| `-upgradeProgress status \| details \| force` | 请求当前系统的升级状态，状态的细节，或者强制升级操作进行。   |
| `-metasave filename`                          | 保存Namenode的主要数据结构到hadoop.log.dir属性指定的目录下的<filename>文件。对于下面的每一项，<filename>中都会一行内容与之对应 1. Namenode收到的Datanode的心跳信号 2. 等待被复制的块 3. 正在被复制的块 4. 等待被删除的块 |
| `-setQuota <quota> <dirname>...<dirname>`     | 为每个目录 <dirname>设定配额<quota>。目录配额是一个长整型整数，强制限定了目录树下的名字个数。 命令会在这个目录上工作良好，以下情况会报错： 1. N不是一个正整数，或者 2. 用户不是管理员，或者 3. 这个目录不存在或是文件，或者 4. 目录会马上超出新设定的配额。 |
| `-clrQuota <dirname>...<dirname>`             | 为每一个目录<dirname>清除配额设定。 命令会在这个目录上工作良好，以下情况会报错： 1. 这个目录不存在或是文件，或者 2. 用户不是管理员。 如果目录原来没有配额不会报错。 |
| `-help [cmd]`                                 | 显示给定命令的帮助信息，如果没有给定命令，则显示所有命令的帮助信息。 |

1. 使用dfsadmin查看文件系统报告
`hdfs dfsadmin -report`
 ```
Configured Capacity: 86905466880 (80.94 GB)
Present Capacity: 77542240256 (72.22 GB)
DFS Remaining: 76954312704 (71.67 GB)
DFS Used: 587927552 (560.69 MB)
DFS Used%: 0.76%
Under replicated blocks: 0
Blocks with corrupt replicas: 0
Missing blocks: 0
Missing blocks (with replication factor 1): 0
Pending deletion blocks: 0
```

## Yarn
### `yarn application -list [options]`
- `-list`:获取yarn应用程序列表(下面是两个可选的过滤器);
    - appStates [ALL, NEW, NEW_SAVING, SUBMITTED, ACCEPTED, RUNNING, FINISHED, FAILED, KILLED];
    - appTypes [MAPREDUCE, ...];

> 示例:`yarn application -list -appStates ALL`

- `-kill <applicationId>` 杀掉指定的应用程序(applicationId: 指定应用程序的ID);
- `-status <applicationId>`打印指定应用程序的状态

### `yarn node [options]`
- `-list`:列出所有RUNNING的节点；
    - `-all`：列出所有节点，不管是什么状态的；
    - `-states <States>`：状态过滤；
    - `-status <nodeId>`：打印指定节点的状态。

### `yarn daemonlog `
- `-getlevel <host:httpport> <classname>` :打印运行在`<host:port>`的守护进程的日志级别。这个命令内部会连接`http://<host:port>/logLevel?log=<name>`;
- `-setlevel <host:httpport> <classname> <level>`：设置运行在`<host:port>`的守护进程的日志级别。这个命令内部会连接`http://<host:port>/logLevel?log=<name>`。

```bash
[root@hadoopcluster78 ~]# yarn daemonlog -getlevel hadoopcluster79:8088 org.apache.hadoop.yarn.server.resourcemanager.rmapp.RMAppImpl
Connecting to http://hadoopcluster79:8088/logLevel?log=org.apache.hadoop.yarn.server.resourcemanager.rmapp.RMAppImpl
Submitted Log Name: org.apache.hadoop.yarn.server.resourcemanager.rmapp.RMAppImpl
Log Class: org.apache.commons.logging.impl.Log4JLogger
Effective level: INFO
 
[root@hadoopcluster78 ~]# yarn daemonlog -getlevel hadoopcluster78:19888 org.apache.hadoop.mapreduce.v2.hs.JobHistory
Connecting to http://hadoopcluster78:19888/logLevel?log=org.apache.hadoop.mapreduce.v2.hs.JobHistory
Submitted Log Name: org.apache.hadoop.mapreduce.v2.hs.JobHistory
Log Class: org.apache.commons.logging.impl.Log4JLogger
Effective level: INFO
```

### `yarn queue [options]`
- `-help`：帮助
- `-status <QueueName>`：打印队列的状态	
