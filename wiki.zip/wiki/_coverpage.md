![logo](/assets/avatar.jpg)

# Kevin

> A magical documentation site generator.

- Simple and lightweight (~21kB gzipped)
- No statically built html files
- Multiple themes

[Getting Started](#Notebook)